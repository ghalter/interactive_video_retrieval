# interactive_video_retrieval

- move and unpack the thumbnails.zip in the "data/"


How to run: 

install the requirements

``pip install -r requirements.txt``

run it with: 

``python app.py``

open your browser and the following url:

``http://127.0.0.1:5000/``